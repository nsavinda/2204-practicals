object Area{

def area(radius:Double):Double = 3.14 * radius * radius

def main(args:Array[String])={
	printf("Area = %f\n", area(5))
}
}
